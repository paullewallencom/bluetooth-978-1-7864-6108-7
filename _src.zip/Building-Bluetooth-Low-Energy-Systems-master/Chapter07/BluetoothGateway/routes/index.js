// var nodes = require('./nodes');
var nodes = require('./nodes');
var services = require('./services');


 //var descriptors = require('./descriptors');

var characteristics = require('./characteristics');
var values = require('./values');

 //module.exports = [].concat(nodes, services, characteristics, descriptors, values);
module.exports = [].concat(nodes, services, characteristics, values);
