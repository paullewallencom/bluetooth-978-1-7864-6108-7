package com.demo.bluetoothscanexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CharacteristicDescriptionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_characteristic_description);
    }
}
